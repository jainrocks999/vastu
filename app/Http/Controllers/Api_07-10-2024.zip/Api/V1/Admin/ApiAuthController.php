<?php

namespace App\Http\Controllers\Api\V1\Admin;
use Botble\ACL\Traits\AuthenticatesUsers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Facades\JWTAuth;
use Botble\ACL\Models\User;
use Botble\ACL\Models\Role;
use Botble\Ecommerce\Models\Customer;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use DB;

class ApiAuthController extends Controller
{
    public function login(Request $request)
    {
        try{    
            $validator = Validator::make($request->all(), [
            'phone_no' => 'nullable|numeric|digits:10',
            ]);
            if ($validator->fails()) {
                $errors = $validator->errors()->all();
                $response =['status'=>400,'msg' => $errors[0]];
                return response($response, 200);
            }
            $user = Customer::where('phone', $request->phone_no)
                        ->where('is_vendor', 0)
                        ->where('status', 'activated')
                        ->first();                
            if($user){
                $otp = mt_rand(100000, 999999);
                $token = JWTAuth::fromUser($user);
                $response = ['status'=>200,
                            'OTP' => $otp,
                            'user_id'=> $user->id,
                            'token'=> $token,
                            'token_type'=>'bearer',
                            'msg'=>"OTP sent to your mobile number."];
                return response($response, 200);
            }else{
                $response = ['status'=>404,'msg'=>"User not found."];
                return response($response, 200);
            }
        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json(['status' => 500, 'msg' => 'Something went wrong.'], 500);
        }
    }


    //Register user
    public function register (Request $request) {
        try {
            $validator = Validator::make($request->all(), [
                'name' => 'required|string|max:255',
                'email' => 'nullable|string|email|max:255',
                'phone' => 'required|numeric|digits:10',
                'user_type' => 'required',
                'password' => 'min:6|required_with:password_confirmation|same:password_confirmation',
                'password_confirmation' => 'min:6'
            ]);
            if ($validator->fails()) {
                $errors = $validator->errors()->all();
                $response =['status'=>400,'msg' => $errors[0]];
                return response($response, 200);
            }else{
                $users = User::where('email',$request->email)->first();
                if(!empty($users) && $users->email == $request->email){
                    $response = ['status'=>400,'msg'=>"User Email already register."];
                    return response($response, 200);
                }else{
                    $customer = Customer::where('phone',$request->phone)->first();
                    if(!empty($customer) && $customer->phone == $request->phone){
                        $response = ['status'=>400,'msg'=>"User phone already register."];
                        return response($response, 200);
                    }
                    $role_id = 2;
                    if($request->user_type == 0){
                        $role_id = 2;
                    }elseif($request->user_type == 1){
                        $role_id = 3;
                    }else{
                        $role_id = 4;
                    }
                    $roles = Role::where('id',$role_id)->first();

                    $param = [];
                    $param['name'] = $request->name; 
                    $param['email'] = $request->email; 
                    $param['password'] = Hash::make($request->password); 
                    $param['username'] = $request->name; 
                    $param['super_user'] = 0; 
                    $param['manage_supers'] = 0; 
                    $param['permissions'] = $roles->permissions; 
                    $users = User::create($param);
                    if(!empty($users)){
                        $rparam = [];
                        $rparam['user_id'] = $users->id; 
                        $rparam['role_id'] = $role_id; 
                        $roles = DB::table('role_users')->insert($rparam);
                    }
                    $param['phone'] = $request->phone; 
                    $param['created_at'] = date('Y-m-d H:i:s'); 
                    $param['confirmed_at'] = date('Y-m-d H:i:s');
                    $param['status'] = 'activated'; 
                    $param['is_vendor'] = $request->phone; 
                    $customers = Customer::create($param);
                }
                if($customers){
                    $response = ['status'=>200,'data'=>$customers,'msg'=>"OTP sent to your mobile number."];
                    return response($response, 200);
                }else{
                    $response = ['status'=>500,'msg'=>"Something went to wrong"];
                    return response($response, 500);
                }
            }
        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json(['status' => 500, 'msg' => 'Something went wrong.'], 500);
        }
    }


    //profile user
    public function profileUpdate(Request $request) {
        try {
            $validator = Validator::make($request->all(), [
                'user_id' => 'required|integer|max:255', 
                'name' => 'nullable|string|max:255',
                'dob' => 'nullable|string|max:255',
                'phone' => 'nullable|numeric|digits:10',
                'old_password' => 'nullable|min:6',
                'password' => 'min:6|required_with:password_confirmation|same:password_confirmation',
                'password_confirmation' => 'min:6'
            ]);
            if ($validator->fails()) {
                $errors = $validator->errors()->all();
                $response =['status'=>400,'msg' => $errors[0]];
                return response($response, 200);
            }else{
                    $customer = Customer::where('id',$request->user_id)->first();
                    if(!empty($customer)){
                        $user = User::where('email',$customer->email)->first();
                        if(!empty($user)){
                            if(isset($request->name) && !empty($request->name)){
                                $user->username = $request->name; 
                            }
                            if(isset($request->old_password) && !empty($request->old_password)){
                                if(Hash::check($request->old_password, $user->password)){
                                    if(isset($request->password) && !empty($request->password)){
                                    $user->password = Hash::make($request->password); 
                                    }
                                }else{
                                    $response = ['status'=>400,'msg'=>"Old password is incorrect."];
                                    return response($response, 200);
                                }
                            }
                            $user->save();
                        }
                        if(isset($request->name) && !empty($request->name)){
                            $customer->name = $request->name; 
                        }
                        if(isset($request->email) && !empty($request->email)){
                            $customer->email = $request->email; 
                        }
                        if(isset($request->password) && !empty($request->password)){
                            if(Hash::check($request->old_password, $customer->password)){
                                if(isset($request->password) && !empty($request->password)){
                                $customer->password = Hash::make($request->password); 
                                }
                            }else{
                                $response = ['status'=>400,'msg'=>"Old password is incorrect."];
                                return response($response, 200);
                            }
                        }
                        if(isset($request->dob) && !empty($request->dob)){
                            $customer->dob = $request->dob; 
                        }
                        if(isset($request->phone) && !empty($request->phone)){
                            $customerPhones = Customer::where('phone',$request->phone)->first();
                            if(isset($customerPhones) && !empty($customerPhones->phone)){
                                $response = ['status'=>200,'msg'=>"Phone number already exist."];
                                return response($response, 200);
                            }else{
                                $customer->phone = $request->phone; 
                            }
                        }
                        if(isset($request->updated_at) && !empty($request->updated_at)){
                            $customer->updated_at = date('Y-m-d H:i:s'); 
                        }
                        $customer->save();
                    }
                if($customer){
                    if(isset($request->old_password) && !empty($request->old_password)){
                        $response = ['status'=>200,'data'=>$customer,'msg'=>"Password update successfully."];
                    }else{
                        $response = ['status'=>200,'data'=>$customer,'msg'=>"Profile update successfully."];
                    }
                    return response($response, 200);
                }else{
                    $response = ['status'=>500,'msg'=>"Something went to wrong"];
                    return response($response, 500);
                }
            }
        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json(['status' => 500, 'msg' => 'Something went wrong.'], 500);
        }
    }

}
